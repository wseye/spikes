/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */

package com.microsoft.servicebus.amqp.samples;

import javax.jms.*;
import javax.naming.NamingException;

public class Sender extends BaseSample
{
    private enum MessageType
    {
        TEXT, BYTES, MAP, STREAM, OBJECT
    }

    private static final String CLASS = "Sender";
    protected static MessageProducer messageProducer = null;
    protected static Destination sendDestination = null;

    private static int messagesSentCounter = 0;

    public static void main(String args[])
    {
        try
        {
            if (init())
            {
                sendMessages();
            }
            shutdown();
        }
        catch (Exception e)
        {
            System.out.println("Exception: " + e);
        }


        System.out.println(CLASS + ": Exiting");
        System.exit(0);
    }

    private static void sendMessages() throws JMSException
    {
        try
        {
            System.out.println(CLASS + ": Sending TextMessage");
            messageProducer.send(createMessage(MessageType.TEXT));

            System.out.println(CLASS + ": Sending BytesMessage");
            messageProducer.send(createMessage(MessageType.BYTES));

            System.out.println(CLASS + ": Sending MapMessage");
            messageProducer.send(createMessage(MessageType.MAP));

            System.out.println(CLASS + ": Sending StreamMessage");
            messageProducer.send(createMessage(MessageType.STREAM));

            System.out.println(CLASS + ": Sending ObjectMessage");
            messageProducer.send(createMessage(MessageType.OBJECT));

        }
        catch (Exception e)
        {
            System.out.println("Caught exception: " + e);
        }
    }

    private static Message createMessage(MessageType type) throws JMSException
    {
        Message message = null;
        if (type == MessageType.TEXT)
        {
            TextMessage textMessage = session.createTextMessage();
            textMessage.setText("This is a JMS TextMessage");
            message = textMessage;
            message.setStringProperty(Constants.MessageTypePropertyName, "TextMessage");
        }
        else if (type == MessageType.BYTES)
        {
            BytesMessage bytesMessage = session.createBytesMessage();
            byte[] bytes = {-128, 127, -1, 0, 1, -64, 64, -128, 127, -1, 0, 1, -64, 64};
            bytesMessage.writeBytes(bytes);
            message = bytesMessage;
            message.setStringProperty(Constants.MessageTypePropertyName, "BytesMessage");
        }
        else if (type == MessageType.STREAM)
        {
            StreamMessage streamMessage = session.createStreamMessage();
            streamMessage.writeString("A String");
            streamMessage.writeDouble(123.456789e222);
            streamMessage.writeInt(223344);
            message = streamMessage;
            message.setStringProperty(Constants.MessageTypePropertyName, "StreamMessage");
        }
        else if (type == MessageType.MAP)
        {
            MapMessage mapMessage = session.createMapMessage();
            mapMessage.setString("A String", "Test String");
            mapMessage.setInt("An Integer", 3456);
            mapMessage.setDouble("A Double", 1.23456789);
            message = mapMessage;
            message.setStringProperty(Constants.MessageTypePropertyName, "MapMessage");
        }
        else if (type == MessageType.OBJECT)
        {
            ObjectMessage objectMessage = session.createObjectMessage();
            objectMessage.setObject("This is a String object");
            message = objectMessage;
            message.setStringProperty(Constants.MessageTypePropertyName, "ObjectMessage");
        }

        // Add JMS Message Headers
        messagesSentCounter++;
        message.setJMSMessageID("ID:TestMessageID-" + messagesSentCounter);
        message.setJMSCorrelationID("TestCorrelationID-" + messagesSentCounter);
        message.setJMSType("TestType-" + messagesSentCounter);
        message.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
        message.setJMSReplyTo(sendDestination);

        // Add Application Properties
        message.setBooleanProperty("TestBoolean", true);
        message.setByteProperty("TestByte", (byte) 33);
        message.setDoubleProperty("TestDouble", 3.14159D);
        message.setFloatProperty("TestFloat", 3.13159F);
        message.setIntProperty("TestInt", 100);
        message.setStringProperty("TestString", "Service Bus");

        return message;
    }


    protected static boolean init()
    {
        System.out.println(CLASS + ": Initializing...");

        Boolean success = BaseSample.init();
        if (success)
        {
            try
            {
                // Lookup the receive destination
                System.out.println(CLASS + ": Looking up send destination " + SEND_DESTINATION_NAME);
                sendDestination = (Destination) context.lookup(SEND_DESTINATION_NAME);

                // Create a MessageConsumer
                System.out.println(CLASS + ": Creating a MessageProducer for " + SEND_DESTINATION_NAME);
                messageProducer = session.createProducer(sendDestination);
                success = true;
            }
            catch (JMSException e)
            {
                System.err.println("ERROR (" + CLASS + "): Caught a JMSException while creating MessageProducer: " + e);
            }
            catch (NamingException e)
            {
                System.err.println("ERROR (" + CLASS + "): Caught an NamingException while looking up destination: " + e);
            }
        }
        return success;
    }

    protected static void shutdown()
    {
        System.out.println(CLASS + ": Shutting down...");

        try
        {
            if (messageProducer != null)
            {
                System.out.println(CLASS + ": Closing MessageProducer");
                messageProducer.close();
            }
        }
        catch (JMSException e)
        {
            System.err.println("ERROR (" + CLASS + "): Caught an Exception while closing MessageProducer: " + e);
        }
        BaseSample.shutdown();
    }
}
