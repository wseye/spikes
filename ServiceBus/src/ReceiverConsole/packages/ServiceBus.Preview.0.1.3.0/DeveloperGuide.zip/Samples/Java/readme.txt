----------------------------------------------
Service Bus AMQP Public Preview - October 2012
----------------------------------------------

These Java samples use the AMQP 1.0 JMS client library developed the Apache Qpid
project. The library is available for download from:
http://people.apache.org/~rgodfrey/qpid-java-amqp-1-0-SNAPSHOT/0.19/qpid-amqp-1-0-SNAPSHOT.zip

This zip archive contains the following eight files:
�	geronimo-jms_1.1_spec-1.0.jar
�	qpid-amqp-1-0-client-0.19-sources.jar
�	qpid-amqp-1-0-client-0.19.jar
�	qpid-amqp-1-0-client-jms-0.19-sources.jar
�	qpid-amqp-1-0-client-jms-0.19.jar
�	qpid-amqp-1-0-common-0.19-sources.jar
�	qpid-amqp-1-0-common-0.19.jar
�	svnversion

The following four JAR files need to be added to the Java CLASSPATH when building and
running JMS applications with Service Bus:
�	geronimo-jms_1.1_spec-1.0.jar
�	qpid-amqp-1-0-client-0.19.jar
�	qpid-amqp-1-0-client-jms-0.19.jar
�	qpid-amqp-1-0-common-0.19.jar

These samples expect that these JARs are located in the lib subdirectory.
