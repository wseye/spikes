/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ---------------------------------------------------------------------------------
 */

package com.microsoft.servicebus.amqp.samples;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;

public class BaseSample
{
    private static final String CLASS = "BaseSample";
    protected static final String CONNECTION_FACTORY_NAME = "ServiceBusConnectionFactory";
    protected static final String SEND_DESTINATION_NAME = "SendToEntity";
    protected static final String RECEIVE_DESTINATION_NAME = "ReceiveFromEntity";
    protected static Context context = null;
    protected static ConnectionFactory connectionFactory = null;
    protected static Connection connection = null;
    protected static Session session = null;

    protected static boolean init()
    {
        boolean success = false;
        try
        {
            System.out.println(CLASS + ": Initializing JMS environment");

            // Set up JNDI environment
            Hashtable<String, String> env = new Hashtable<String, String>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.qpid.amqp_1_0.jms.jndi.PropertiesFileInitialContextFactory");
            env.put(Context.PROVIDER_URL, "servicebus.properties");

            // Create JNDI InitialContext
            System.out.println(CLASS + ": Creating JNDI InitialContext");
            context = new InitialContext(env);

            // Lookup the ConnectionFactory
            System.out.println(CLASS + ": Looking up ConnectionFactory");
            connectionFactory = (ConnectionFactory) context.lookup(CONNECTION_FACTORY_NAME);

            // Create the Connection
            System.out.println(CLASS + ": Creating a Connection");
            connection = connectionFactory.createConnection();

            // Create a non-transacted, auto-acknowledge session
            System.out.println(CLASS + ": Creating a non-transacted, auto-acknowledged Session");
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            success = true;
        }
        catch (Exception e)
        {
            System.err.println("ERROR (" + CLASS + "): Caught an Exception while setting up JMS environment: " + e);
            e.printStackTrace();
        }
        return success;
    }

    protected static void shutdown()
    {
        System.out.println(CLASS + ": Shutting down...");
        if (session != null)
        {
            System.out.println(CLASS + ": Closing Session");
            try
            {
                session.close();
            }
            catch (JMSException e)
            {
                System.err.println("ERROR (" + CLASS + "): Caught an Exception while closing Session: " + e);
            }
        }

        if (connection != null)
        {
            System.out.println(CLASS + ": Closing Connection");
            try
            {
                connection.close();
            }
            catch (JMSException e)
            {
                System.err.println("ERROR (" + CLASS + "): Caught an Exception while closing Connection: " + e);
            }
        }

        if (context != null)
        {
            System.out.println(CLASS + ": Closing JNDI context");
            try
            {
                context.close();
            }
            catch (NamingException e)
            {
                System.err.println("ERROR (" + CLASS + "): Caught an Exception while closing JNDI context: " + e);
            }
        }
    }
}
