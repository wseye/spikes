/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ---------------------------------------------------------------------------------
 */

package com.microsoft.servicebus.amqp.samples;

import org.apache.qpid.amqp_1_0.type.Section;

import javax.jms.*;
import java.util.Enumeration;

public class Listener implements MessageListener
{
    private static final String CLASS = "Listener";
    private static int receivedMessageCount = 0;

    public Listener()
    {
        System.out.println(CLASS + ": Listener constructed");
    }

    public void onMessage(Message message)
    {
        System.out.println();
        System.out.println(CLASS + ": Message received " + ++receivedMessageCount);
        try
        {
            displayMessageBody(message);
            displayMessageHeaders(message);
            displayApplicationProperties(message);
            System.out.println();
        }
        catch (JMSException e)
        {
            System.err.println(CLASS + ": Exception: ");
            e.printStackTrace();
        }
    }

    private static void displayMessageBody(Message message) throws JMSException
    {
        if (message instanceof TextMessage)
        {
            System.out.println("\n\tTextMessage body:");
            System.out.println("\t\tText:" + ((TextMessage) message).getText());
        }
        else if (message instanceof BytesMessage)
        {
            System.out.println("\n\tBytesMessage body: ");
            int messageBodyLength = (int) ((BytesMessage) message).getBodyLength();
            int numBytesToRead = (messageBodyLength < 10) ? messageBodyLength : 10;
            byte[] byteArray = new byte[numBytesToRead];
            ((BytesMessage) message).readBytes(byteArray, numBytesToRead);
            System.out.println("\t\tLength = " + messageBodyLength + ", displaying " + numBytesToRead + " bytes:");
            System.out.print("\t\t");
            for (int i = 0; i < numBytesToRead; i++)
            {
                System.out.print("[" + byteArray[i] + "]");
            }
            System.out.println();
        }
        else if (message instanceof MapMessage)
        {
            System.out.println("\n\tMapMessage body: ");
            Enumeration mapNames = ((MapMessage) message).getMapNames();
            while (mapNames.hasMoreElements())
            {
                String name = (String) mapNames.nextElement();
                Object value = ((MapMessage) message).getObject(name);
                System.out.println("\t\t" + name + ":=" + value + " (" + value.getClass().getSimpleName() + ")");
            }
        }
        else if (message instanceof StreamMessage)
        {
            System.out.println("\n\tStreamMessage body: ");
            StreamMessage streamMessage = (StreamMessage) message;

            Object obj;
            try
            {
                while ((obj = streamMessage.readObject()) != null)
                {
                    System.out.println("\t\t" + obj.toString() + " (" + obj.getClass().getSimpleName() + ")");
                }
            }
            catch (MessageEOFException e)
            {
                // Expected when end of stream reached.
            }
            catch (JMSException e)
            {
                System.err.print("\n\tCaught exception decoding StreamMessage: " + e);
            }
        }
        else if (message instanceof ObjectMessage)
        {
            System.out.println("\n\tObjectMessage body: ");
            System.out.println("\t\tObject: " + ((ObjectMessage) message).getObject());
        }
        else if (message instanceof org.apache.qpid.amqp_1_0.jms.impl.AmqpMessageImpl)
        {
            System.out.println("\n\tAmqpMessageImpl body: ");
            org.apache.qpid.amqp_1_0.jms.impl.AmqpMessageImpl amqpMessage = (org.apache.qpid.amqp_1_0.jms.impl.AmqpMessageImpl) message;

            for (int i = 0; i < amqpMessage.getSectionCount(); i++)
            {
                Section section = amqpMessage.getSection(i);
                System.out.println("\t\tSection " + i + ": " + section.toString());
            }
        }
        else
        {
            System.out.print("\n\tUnrecognized JMS message type. Class = " + message.getClass());
        }
    }

    private static void displayMessageHeaders(Message message) throws JMSException
    {
        System.out.println("\tJMS headers: ");
        System.out.println("\t\t" + "JMSCorrelationID" + ": " + message.getJMSCorrelationID());

        int deliveryMode = message.getJMSDeliveryMode();
        if (deliveryMode == DeliveryMode.NON_PERSISTENT)
        {
            System.out.println("\t\t" + "JMSDeliveryMode: NON_PERSISTENT (" + deliveryMode + ")");
        }
        else if (deliveryMode == DeliveryMode.PERSISTENT)
        {
            System.out.println("\t\t" + "JMSDeliveryMode: PERSISTENT (" + deliveryMode + ")");
        }
        else
        {
            System.out.println("\t\t" + "JMSDeliveryMode: Unrecognized (" + deliveryMode + ")");
        }
        Destination d = message.getJMSDestination();
        if (d == null)
        {
            System.out.println("\t\t" + "JMSDestination" + ": not set (null)");
        }
        else
        {
            if (d instanceof Queue)
            {
                System.out.println("\t\t" + "JMSDestination" + ": (Queue) " + ((Queue) d).getQueueName());
            }
            else if (d instanceof Topic)
            {
                System.out.println("\t\t" + "JMSDestination" + ": (Topic) " + ((Topic) d).getTopicName());
            }
            else
            {
                System.out.println("\t\t" + "JMSDestination" + ": " + d);
            }
        }
        System.out.println("\t\t" + "JMSExpiration" + ": " + message.getJMSExpiration());
        System.out.println("\t\t" + "JMSMessageID" + ": " + message.getJMSMessageID());
        System.out.println("\t\t" + "JMSPriority" + ": " + message.getJMSPriority());
        System.out.println("\t\t" + "JMSRedelivered" + ": " + message.getJMSRedelivered());
        Destination replyTo = message.getJMSReplyTo();
        if (replyTo == null)
        {
            System.out.println("\t\t" + "JMSReplyTo" + ": not set (null)");
        }
        else
        {
            if (replyTo instanceof Queue)
            {
                System.out.println("\t\t" + "JMSReplyTo" + ": (Queue) " + ((Queue) replyTo).getQueueName());
            }
            else if (d instanceof Topic)
            {
                System.out.println("\t\t" + "JMSReplyTo" + ": (Topic) " + ((Topic) replyTo).getTopicName());
            }
            else
            {
                System.out.println("\t\t" + "JMSReplyTo" + ": " + replyTo);
            }
        }

        java.util.Date timestampInDateFormat = new java.util.Date(message.getJMSTimestamp());
        System.out.println("\t\t" + "JMSTimestamp" + ": " + timestampInDateFormat);
        System.out.println("\t\t" + "JMSType" + ": " + message.getJMSType());
    }

    private static void displayApplicationProperties(Message message) throws JMSException
    {
        Enumeration propertyNames = message.getPropertyNames();

        if (propertyNames.hasMoreElements())
        {
            System.out.println("\tApplication properties: ");
        }

        while (propertyNames.hasMoreElements())
        {
            String name = (String) propertyNames.nextElement();
            Object value = message.getObjectProperty(name);
            System.out.println("\t\t" + name + ": " + value + " (" + value.getClass().getSimpleName() + ")");
        }

    }

}
