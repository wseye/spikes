/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */

package com.microsoft.servicebus.amqp.samples;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.naming.NamingException;

public class Receiver extends BaseSample
{

    private static final String CLASS = "Receiver";
    protected static MessageConsumer messageConsumer = null;
    private static Destination receiveDestination = null;

    public static void main(String args[])
    {
        try
        {
            if (init())
            {
                messageConsumer.setMessageListener(new Listener());
                connection.start();
            }

            System.out.println("Press <Enter> to stop");
            System.in.read();

            shutdown();
        }
        catch (Exception e)
        {
            System.out.println("Exception: " + e);
        }

        System.out.println(CLASS + ": Exiting");
        System.exit(0);
    }

    protected static boolean init()
    {
        System.out.println(CLASS + ": Initializing...");

        Boolean success = BaseSample.init();
        if (success)
        {
            try
            {
                // Lookup the receive destination
                System.out.println(CLASS + ": Looking up receiveDestination " + RECEIVE_DESTINATION_NAME);
                receiveDestination = (Destination) context.lookup(RECEIVE_DESTINATION_NAME);

                // Create a MessageConsumer
                System.out.println(CLASS + ": Creating a MessageConsumer for " + RECEIVE_DESTINATION_NAME);
                messageConsumer = session.createConsumer(receiveDestination);
                success = true;
            }
            catch (JMSException e)
            {
                e.printStackTrace();
            }
            catch (NamingException e)
            {
                e.printStackTrace();
            }
        }
        return success;
    }

    protected static void shutdown()
    {
        System.out.println(CLASS + ": Shutting down...");

        try
        {
            if (messageConsumer != null)
            {
                System.out.println(CLASS + ": Closing MessageConsumer");
                messageConsumer.close();
            }
        }
        catch (JMSException e)
        {
            System.err.println("ERROR (" + CLASS + "): Caught an Exception while closing MessageConsumer: " + e);
        }
        BaseSample.shutdown();
    }

}
