#!/usr/bin/python

# ---------------------------------------------------------------------------------
# Copyright (c) 2012, Microsoft Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ---------------------------------------------------------------------------------

import sys, optparse
from proton import Messenger, Message, Timeout
from threading import Thread

broker = "amqps://[issuer-name]:[issuer-key]@[namespace].servicebus.windows.net"
entity = "queue1"

def render_bytes(b):
  return repr(b)

def render_unicode(u):
  return u

def render_list(l):
  return str(l)

def render_dict(d):
  return str(d)

def render_default(x):
  return repr(x)

RENDERERS = {
  bytes: render_bytes,
  unicode: render_unicode,
  list: render_list,
  dict: render_dict
  }

def render(x):
  r = RENDERERS.get(x.__class__, render_default)
  return r(x)

def display_message(message):
   print "\tBody: " + render(message.body)

   print "\tMessage Properties:"
   print "\t\tcontent_type: %s" % message.content_type
   print "\t\tcorrelation_id: %s" % message.correlation_id
   print "\t\tsubject: %s" %  message.subject
   print "\t\tid: %s" %  message.id
   print "\t\treply_to: %s" %  message.reply_to
   print "\t\treply_to_group_id: %s" %  message.reply_to_group_id
   print "\t\tgroup_id: %s" %  message.group_id
   print "\t\tuser_id: %s" %  message.user_id
   print "\t\tttl: %s" %  message.ttl

   print "\tApplication Properties:"
   if message.properties != None:
      for k,v in message.properties.items():
         try:
            print "\t\t%s : %r (%s)" % (k, v, type(v))
         except Exception, ex:
            print "Error when printing %s: %s" % (k, ex)
   else:
      print "\t\tMessage has no properties"

address = "%s/%s" % (broker, entity)
print "Receiving messages from %s" % address

def receiver():
  messenger = Messenger()
  messenger.subscribe(address)
  messenger.timeout = 5000
  messenger.start()
  messagesReceived = 0

  message = Message()
  while running:
    try:
	  messenger.recv(10)
    except Timeout:
	  pass
    except Exception, e:
      print str(e)      
    else:
      while messenger.incoming > 0:
        messenger.get(message)
        messagesReceived += 1
        print "\nReceived message " + str(messagesReceived)
        display_message(message)
  messenger.stop()

running = True
thread = Thread(target=receiver)
thread.daemon = True
thread.start()

print "Press enter to stop"
raw_input()
print "Stopping..."
running = False
thread.join()
print "Done"
