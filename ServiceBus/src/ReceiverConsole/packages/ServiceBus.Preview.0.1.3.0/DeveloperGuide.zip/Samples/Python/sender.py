#!/usr/bin/python

# ---------------------------------------------------------------------------------
# Copyright (c) 2012, Microsoft Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ---------------------------------------------------------------------------------

import sys, optparse, datetime, uuid, datetime, urlparse
from proton import Messenger, Message

broker = "amqps://[issuer-name]:[issuer-key]@[namespace].servicebus.windows.net"
entity = "queue1"

TEXT_MESSAGE = u"TextMessage"
BYTES_MESSAGE = u"BytesMessage"
MAP_MESSAGE = u"MapMessage"
STREAM_MESSAGE = u"StreamMessage"

def create_message(message_type, address, message_id):
    message = Message()
    message.clear()
    message.properties = {}
    message.properties[u"MessageType"] = message_type
    message.properties[u"Originator"] = u"Proton-Python"
    message.address = address
    
    if message_type == TEXT_MESSAGE:
        message.body = u"This is a text message"        
    elif message_type == BYTES_MESSAGE:
        message.body = "This is a bytes message"
    elif message_type == MAP_MESSAGE:
        message.body = {u"key": u"value", u"key1" : u"value1"}
    elif message_type == STREAM_MESSAGE:
        message.body = [u"String 1", u"String 2", u"String 3", 3.14159]
    
    # Add message headers
    message.content_type = 'TestContentType-%s' % message_id
    message.correlation_id = message_id
    message.subject = 'TestLabel-%s' % message_id
    message.id = u'TestMessageId-%s' % message_id
    message.reply_to = 'TestReplyTo-%s' % message_id
    message.reply_to_group_id = 'TestReplyToSessionId-%s' % message_id
    message.group_id = 'TestSessionId-%s' % message_id
    message.user_id = u'TestTo-%s' % message_id
    message.ttl = 8640000 #1 day = 8640000 milliseconds
    
    # Add application properties   
    message.properties[u"TestString"] = "Service Bus"
    message.properties[u"TestStringUnicode"] = u"Service Bus \x21\x23\x24"
    message.properties[u"TestInt"] = 1
    message.properties[u"TestLong"] = 1000L
    message.properties[u"TestFloat"] = 1.5    
    message.properties[u"TestGuid"] = uuid.uuid1()
    message.properties[u"TestUri"] = urlparse.urlparse('http://www.bing.com').geturl()
    message.properties[u"TestBoolean"] = False
    #message.properties[u"TestDateTime"] = datetime.datetime.now()    
    #message.properties[u"TestTimeSpan"] = datetime.timedelta(minutes=5)  

    return message

messenger = Messenger()
address = "%s/%s" % (broker, entity)
print "Sending messages to %s" % address

text_message_id = uuid.uuid1()
message = create_message(TEXT_MESSAGE, address, text_message_id)
messenger.put(message)
messenger.send()
print "Sent TextMessage with id %s" % text_message_id

bytes_message_id = uuid.uuid1()
message = create_message(BYTES_MESSAGE, address, bytes_message_id)
messenger.put(message)
messenger.send()
print "Sent BytesMessage with id %s" % bytes_message_id

map_message_id = uuid.uuid1()
message = create_message(MAP_MESSAGE, address, map_message_id)
messenger.put(message)
messenger.send()
print "Sent MapMessage with id %s" % map_message_id

list_message_id = uuid.uuid1()
message = create_message(STREAM_MESSAGE, address, list_message_id)
messenger.put(message)
messenger.send()
print "Sent StreamMessage with id %s" % list_message_id

print "done"
