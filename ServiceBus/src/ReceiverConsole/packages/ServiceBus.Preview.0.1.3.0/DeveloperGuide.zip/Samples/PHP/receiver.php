<?php

/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */
 
include("proton.php");
gc_enable();

$broker = "amqps://[issuer-name]:[issuer-key]@[namespace].servicebus.windows.net";
$entity = "queue1";

define("TEXT_MESSAGE", "TextMessage");
define("BYTES_MESSAGE","BytesMessage");
define("MAP_MESSAGE","MapMessage");
define("STREAM_MESSAGE","StreamMessage");

function display_message($message)
{
  print("\tBody:\n\t\t");
  print_r($message->body);
  print("\n");

  print("\tMessage Properties: \n");
  printf("\t\tcontent_type: %s\n", $message->content_type);
  printf("\t\tcorrelation_id: %s\n", $message->correlation_id);
  printf("\t\tsubject: %s\n",  $message->subject);
  printf("\t\tid: %s\n",  $message->id);
  printf("\t\treply_to: %s\n",  $message->reply_to);
  printf("\t\treply_to_group_id: %s\n",  $message->reply_to_group_id);
  printf("\t\tgroup_id: %s\n",  $message->group_id);
  printf("\t\tuser_id: %s\n",  $message->user_id);
  printf("\t\tttl: %s\n",  $message->ttl);
  printf("\t\tenqueued time: %s \n", $message->annotations["x-opt-enqueued-time"]);
  printf("\t\tscheduled enqueued time: %s \n", $message->annotations["x-opt-scheduled-enqueue-time"]);  
 
  print("\tApplication properties \n");
	if($message->properties != null)
	{
    foreach($message->properties as $key => $value)
    {
      printf("\t\t%s: %s (%s) \n", $key, $value, gettype($value));
		}         
	}
  else
  {
		print("Message has no properties \n");
  }
}

function receiver()
{
  global $broker, $entity;

  $address = "$broker/$entity";
  printf("Receiving messages from %s\n", $address);
  
  $messenger = new Messenger();
  $messenger->subscribe($address);
  $messenger->timeout = 5000;
  $messenger->start();
  $messagesReceived = 0;

  while(true)
  {
    try
    {
      $messenger->recv(10);

      while ($messenger->incoming() > 0)
      {
         $message = new Message();
         $messenger->get($message); 
         $messagesReceived += 1;
         printf ("\nReceived message %s\n", $messagesReceived);
         display_message($message);   
      }
    }
    catch (Timeout $e)
    {
    }    
  }
}

print ("Press ctrl-C to stop\n");
receiver();
?>
