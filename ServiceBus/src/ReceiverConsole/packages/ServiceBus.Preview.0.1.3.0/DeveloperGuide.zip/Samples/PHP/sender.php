<?php

/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */
 
include("proton.php");
gc_enable();

$broker = "amqps://[issuer-name]:[issuer-key]@[namespace].servicebus.windows.net";
$entity = "queue1";

define("TEXT_MESSAGE", "TextMessage");
define("BYTES_MESSAGE","BytesMessage");
define("MAP_MESSAGE","MapMessage");
define("STREAM_MESSAGE","StreamMessage");

function create_message($message_type, $address, $message_id)
{
	$message = new Message();
    $message->clear();
    $message->properties = array();
    $message->properties["MessageType"] = $message_type;
    $message->properties["Originator"] = "PROTON-PHP";
    $message->address = $address;

    switch ($message_type) {
    	case TEXT_MESSAGE:
    		$message->body = "This is a text message";
    		break;
    	case BYTES_MESSAGE:
    		$message->body = new Binary("This is a binary body");
    		break;
    	case MAP_MESSAGE:    		
    		$message->body = array("key" => "value", "key1" => "value1");
    		break;
    	case STREAM_MESSAGE:
    		$message->body = new PList("String 1", "String 2", "String 3", 3.14159);
    	    break;
    }	   

    // Add message properties
    $message->content_type = sprintf("TestContentType-%s", $message_id);
    $message->correlation_id = $message_id;
    $message->subject = sprintf("TestLabel-%s" , $message_id);
    $message->id = sprintf("TestMessageId-%s" , $message_id);
    $message->reply_to = sprintf("TestReplyTo-%s" , $message_id);
    $message->reply_to_group_id = sprintf("TestReplyToSessionId-%s" , $message_id);
    $message->group_id = sprintf("TestSessionId-%s" , $message_id);
    $message->user_id = sprintf("TestTo-%s" , $message_id);
    $message->ttl = 8640000; //1 day = 8640000 milliseconds

    $message->properties["TestString"] = "Service Bus";
    $message->properties["TestStringUnicode"] = new Binary("Service Bus \x21\x23\x24");
    $message->properties["TestInt"] = 1;    
    $message->properties["TestFloat"] = 1.5;  
    $message->properties["TestGuid"] = new UUID("1234123412341234");
    $message->properties["TestUri"] = "http://www.bing.com";
    $message->properties["TestBoolean"] = False;
    return $message;
}

$messenger = new Messenger();
$address = "$broker/$entity";
$text_message_id = new UUID("1234123412341234");
$message = create_message(TEXT_MESSAGE, $address, $text_message_id);
$messenger->put($message);
$messenger->send();
printf("Sent TextMessage with id %s \n", $text_message_id);

$bytes_message_id = new UUID("1234123412341234");
$message = create_message(BYTES_MESSAGE, $address, $bytes_message_id);
$messenger->put($message);
$messenger->send();
printf("Sent BytesMessage with id %s \n", $bytes_message_id);

$map_message_id = new UUID("1234123412341234");
$message = create_message(MAP_MESSAGE, $address, $map_message_id);
$messenger->put($message);
$messenger->send();
printf("Sent MapMessage with id %s \n", $map_message_id);

$stream_message_id = new UUID("1234123412341234");
$message = create_message(STREAM_MESSAGE, $address, $stream_message_id);
$messenger->put($message);
$messenger->send();
printf("Sent StreamMessage with id %s \n",  $stream_message_id);

print("Done \n");
?>
