﻿/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */

using System;
using System.Configuration;
using System.Collections.Generic;
using Microsoft.ServiceBus.Messaging;

namespace Microsoft.ServiceBus.Samples.Amqp
{
    class Admin
    {
        static Boolean initialized = false;
        static NamespaceManager namespaceManager = null;

        static void Main(string[] args)
        {
            if (!Init())
            {
                Console.WriteLine("Failed to initialized. Exiting.");
            }
            else
            {
                Menu();
            }
        }

        private static Boolean Init()
        {
            if (!initialized)
            {
                string connectionString = ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];

                if (connectionString != null)
                {
                    Console.WriteLine("Initializing...");
                    namespaceManager = NamespaceManager.CreateFromConnectionString(connectionString);
                    initialized = true;
                }
                else
                {
                    Console.WriteLine("Couldn't find ConnectionString, check app.config file.");
                }
            }
            return initialized;
        }

        private static void Menu()
        {
            string resp;
            do
            {
                Console.WriteLine("\nMENU");
                Console.WriteLine("\t P\t Provision sample messaging entities");
                Console.WriteLine("\t D\t Delete sample messaging entities");
                Console.WriteLine("\t E\t Enumerate all messaging entities in namespace");
                Console.WriteLine("\t DA\t Delete all messaging entities in namespace - be careful!");
                Console.WriteLine("\t .\t Exit");
                resp = (Console.ReadLine()).ToLower();
                Console.WriteLine();

                if (resp == "e")
                {
                    EnumerateEntities();
                }
                else if (resp == "p")
                {
                    ProvisionEntities();
                }
                else if (resp == "d")
                {
                    DeleteEntities();
                }
                else if (resp == "da")
                {
                    DeleteAllEntities();
                }
            }
            while (resp != ".");
        }

        private static void ProvisionEntities()
        {
            try
            {
                // Queues
                for (int i = 0; i < Constants.Queues.Length; i++)
                {
                    try
                    {
                        Console.WriteLine("Creating queue: " + Constants.Queues[i]);
                        namespaceManager.CreateQueue(Constants.Queues[i]);
                    }
                    catch (MessagingEntityAlreadyExistsException)
                    {
                        Console.WriteLine("Entity already exists: " + Constants.Queues[i]);
                    }
                }

                // Topics
                for (int i = 0; i < Constants.Topics.Length; i++)
                {
                    try
                    {
                        Console.WriteLine("Creating topic: " + Constants.Topics[i]);
                        namespaceManager.CreateTopic(Constants.Topics[i]);
                    }
                    catch (MessagingEntityAlreadyExistsException)
                    {
                        Console.WriteLine("Entity already exists: " + Constants.Topics[i]);
                    }

                    // Subscriptions
                    for (int j = 0; j < Constants.Subscriptions.Length; j++)
                    {
                        try
                        {
                            Console.WriteLine("Creating subscription " + Constants.Subscriptions[j] + " on topic " + Constants.Topics[i]);
                            namespaceManager.CreateSubscription(Constants.Topics[i], Constants.Subscriptions[j]);
                        }
                        catch (MessagingEntityAlreadyExistsException)
                        {
                            Console.WriteLine("Subscription already exists: " + Constants.Subscriptions[j] + " on topic " + Constants.Topics[i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception during provisioning: " + e);
            }
        }

        private static void DeleteEntities()
        {
            try
            {
                // Queues
                for (int i = 0; i < Constants.Queues.Length; i++)
                {
                    try
                    {
                        Console.WriteLine("Deleting queue: " + Constants.Queues[i]);
                        namespaceManager.DeleteQueue(Constants.Queues[i]);
                    }
                    catch (MessagingEntityNotFoundException)
                    {
                        Console.WriteLine("Queue node found: " + Constants.Queues[i]);
                    }
                }

                // Topics
                for (int i = 0; i < Constants.Topics.Length; i++)
                {
                    try
                    {
                        Console.WriteLine("Deleting topic: " + Constants.Topics[i]);
                        namespaceManager.DeleteTopic(Constants.Topics[i]);
                    }
                    catch (MessagingEntityNotFoundException)
                    {
                        Console.WriteLine("Topic node found: " + Constants.Topics[i]);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception during delete: " + e);
            }

        }

        private static void EnumerateEntities()
        {
            Console.WriteLine("Enumerating entities:");

            try
            {
                // Queues
                foreach (QueueDescription q in namespaceManager.GetQueues())
                {
                    Console.WriteLine("\tQueue: {0}", q.Path);
                }

                // Topics
                foreach (TopicDescription t in namespaceManager.GetTopics())
                {
                    Console.WriteLine("\tTopic: {0}", t.Path);

                    // Subscriptions
                    foreach (SubscriptionDescription s in namespaceManager.GetSubscriptions(t.Path))
                    {
                        Console.WriteLine("\t\tSubscription: {0}", s.Name);

                        // Rules
                        foreach (RuleDescription r in namespaceManager.GetRules(t.Path, s.Name))
                        {
                            Console.WriteLine("\t\t\tRule: {0}", r.Name);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception while enumerating: " + e);
            }
        }

        private static void DeleteAllEntities()
        {
            // Queues
            foreach (QueueDescription qd in namespaceManager.GetQueues())
            {
                try
                {
                    Console.WriteLine("Deleting queue: " + qd.Path);
                    namespaceManager.DeleteQueue(qd.Path);
                }
                catch
                {
                    Console.WriteLine("Caught exception deleting queue: " + qd.Path);
                }
            }
            // Topics
            foreach (TopicDescription td in namespaceManager.GetTopics())
            {
                try
                {
                    Console.WriteLine("Deleting topic: " + td.Path);
                    namespaceManager.DeleteTopic(td.Path);
                }
                catch
                {
                    Console.WriteLine("Caught exception deleting topic: " + td.Path);
                }
            }
        }
    }
}
