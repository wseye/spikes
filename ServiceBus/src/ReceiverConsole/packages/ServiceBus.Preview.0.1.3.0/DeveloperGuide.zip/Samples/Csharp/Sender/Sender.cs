﻿/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */

using System;
using System.IO;
using System.Configuration;
using System.Collections.Generic;
using Microsoft.ServiceBus.Messaging;

namespace Microsoft.ServiceBus.Samples.Amqp
{
    class Sender
    {
        private static MessagingFactory messagingFactory = null;
        static System.Collections.Hashtable messageSenderHashtable = null;
        private static String destination = null;
        private static int messagesSentCounter = 0;

        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                destination = args[0];
                Initialize();
                SendMessage(destination);
                Shutdown();
            }
            else
            {
                Console.WriteLine("Usage: Sender <destination>");
            }
        }

        static void Initialize()
        {
            string connectionString = ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];
            messagingFactory = MessagingFactory.CreateFromConnectionString(connectionString);
        }


        static void SendMessage(string destination)
        {
            MessageSender sender = GetMessageSender(destination);

            Console.WriteLine("Sending text message to " + destination);
            sender.Send(CreateMessage(MessageType.TEXT));

            Console.WriteLine("Sending bytes message to " + destination);
            sender.Send(CreateMessage(MessageType.BYTES));

            Console.WriteLine("Sending map message to " + destination);
            sender.Send(CreateMessage(MessageType.MAP));

            Console.WriteLine("Sending stream message to " + destination);
            sender.Send(CreateMessage(MessageType.STREAM));
        }

        static MessageSender GetMessageSender(string destination)
        {
            MessageSender sender = null;

            if (messageSenderHashtable == null)
            {
                messageSenderHashtable = new System.Collections.Hashtable();
            }

            if (messageSenderHashtable.ContainsKey(destination))
            {
                sender = (MessageSender)messageSenderHashtable[destination];
            }
            else
            {
                Console.WriteLine("Creating message sender for: " + destination);
                sender = messagingFactory.CreateMessageSender(destination);
                messageSenderHashtable.Add(destination, sender);
            }
            return sender;
        }

        public static BrokeredMessage CreateMessage(MessageType type)
        {
            BrokeredMessage message = null;

                if (type == MessageType.TEXT)
                {
                    message = new BrokeredMessage("this is a text string");
                    message.Properties[Constants.MessageTypePropertyName] = "TextMessage";
                }
                else if (type == MessageType.BYTES)
                {
                    byte[] bytes = { 33, 12, 45, 33, 12, 45, 33, 12, 45, 33, 12, 45 };
                    message = new BrokeredMessage(bytes);
                    message.Properties[Constants.MessageTypePropertyName] = "BytesMessage";
                }
                else if (type == MessageType.MAP)
                {
                    Dictionary<String, Object> dictionary = new Dictionary<String, Object>();
                    dictionary.Add("A String", "Test String");
                    dictionary.Add("An Integer", 3456);
                    dictionary.Add("A Double", (double)1.23456789);
                    message = new BrokeredMessage(dictionary);
                    message.Properties[Constants.MessageTypePropertyName] = "MapMessage";
                }
                else if (type == MessageType.STREAM)
                {
                    List<Object> list = new List<Object>();
                    list.Add("String 1");
                    list.Add("String 2");
                    list.Add("String 3");
                    list.Add((double)3.14159);
                    message = new BrokeredMessage(list);
                    message.Properties[Constants.MessageTypePropertyName] = "StreamMessage";
                }
            else
            {
                message = new BrokeredMessage();
            }

            // Add Application Properties -- Service Bus supports the following property types:
            //     byte, sbyte, char, short, ushort, int, uint, long, ulong, float, double, 
            //     decimal, bool, Guid, string, Uri, DateTime, DateTimeOffset, TimeSpan 

            message.Properties["TestByte"] = (byte)128;
            message.Properties["TestSbyte"] = (sbyte)-22;
            message.Properties["TestChar"] = (char) 'X';
            message.Properties["TestShort"] = (short)-12345;
            message.Properties["TestUshort"] = (ushort)12345;
            message.Properties["TestInt"] = (int)-100;
            message.Properties["TestUint"] = (uint)100;
            message.Properties["TestLong"] = (long)-12345;
            message.Properties["TestUlong"] = (ulong)12345;
            message.Properties["TestFloat"] = (float)3.14159;
            message.Properties["TestDouble"] = (double)3.14159;
            message.Properties["TestDecimal"] = (decimal)3.14159;
            message.Properties["TestBoolean"] = true;
            message.Properties["TestGuid"] = Guid.NewGuid();
            message.Properties["TestString"] = "Service Bus";
            message.Properties["TestUri"] = new Uri("http://www.bing.com");
            message.Properties["TestDateTime"] = DateTime.Now;
            message.Properties["TestDateTimeOffSet"] = DateTimeOffset.Now;
            message.Properties["TestTimeSpan"] = TimeSpan.FromMinutes(60);

            message.Properties["Originator"] = ".NET";

            // Add Message Headers

            messagesSentCounter++;
            message.ContentType = "TestContentType-" + messagesSentCounter;
            message.CorrelationId = "TestCorrelationId-" + messagesSentCounter;
            message.Label = "TestLabel-" + messagesSentCounter;
            message.MessageId = "TestMessageId-" + messagesSentCounter;
            message.ReplyTo = "TestReplyTo-" + messagesSentCounter;
            message.ReplyToSessionId = "TestReplyToSessionId-" + messagesSentCounter;
            message.ScheduledEnqueueTimeUtc = DateTime.Now;
            message.SessionId = "TestSessionId-" + messagesSentCounter;
            message.TimeToLive = TimeSpan.FromDays(1);
            message.To = "TestTo-" + messagesSentCounter;

            return message;
        }

        static void Shutdown()
        {
            try
            {
                foreach (System.Collections.DictionaryEntry de in messageSenderHashtable)
                {
                    Console.WriteLine("Closing MessageSender for " + de.Key);
                    MessageSender ms = (MessageSender)de.Value;
                    ms.Close();
                }

                Console.WriteLine("Closing MessagingFactory");
                messagingFactory.Close();

            }
            catch
            {
                Console.WriteLine("An error occurred during shutdown, ignoring.");
            }
        }        
    }
}
