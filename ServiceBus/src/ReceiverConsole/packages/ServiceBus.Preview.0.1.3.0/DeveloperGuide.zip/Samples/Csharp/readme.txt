----------------------------------------------
Service Bus AMQP Public Preview - October 2012
----------------------------------------------

Accessing the AMQP 1.0 support in Service Bus from .NET requires an updated client
library. This can be downloaded via NuGet. The package is entitled �ServiceBus.Preview�
and it contains a new Service Bus library named �Microsoft.ServiceBus.Preview.dll.�
This library should be used instead of the production version
(�Microsoft.ServiceBus.DLL�) in order to use the AMQP 1.0 features.

The Visual Studio solution file (Samples.sln) assumes that the client library
(Microsoft.ServiceBus.Preview.dll) is located in the lib subdirectory.

Update the Service Bus Connection String for your namespace in the App.config files for
the Admin, Sender and Receiver projects.
