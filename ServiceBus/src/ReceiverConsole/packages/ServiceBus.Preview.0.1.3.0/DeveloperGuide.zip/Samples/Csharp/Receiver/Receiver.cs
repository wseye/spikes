﻿/**
 * ---------------------------------------------------------------------------------
 * Copyright (c) 2012, Microsoft Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *---------------------------------------------------------------------------------
 */

using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using Microsoft.ServiceBus.Messaging;

namespace Microsoft.ServiceBus.Samples.Amqp
{
    class Receiver
    {
        private static MessagingFactory messagingFactory = null;
        static System.Collections.Hashtable messageReceiverHashtable = null;
        private static String destination = null;
        private static int receivedMessageCount = 0;

        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                destination = args[0];
                Initialize();
                ReceiveMessages(destination);
                Shutdown();
            }
            else
            {
                Console.WriteLine("Usage: Receiver <destination>");
            }
        }

        static void Initialize()
        {
            string connectionString = ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];
            messagingFactory = MessagingFactory.CreateFromConnectionString(connectionString);
        }

        static void ReceiveMessages(string destination)
        {
            MessageReceiver receiver = GetMessageReceiver(destination);

            Console.WriteLine("Receiving messages from " + destination);
            Console.WriteLine("Press any key to stop");
            Console.WriteLine();

            while (true)
            {
                BrokeredMessage message = receiver.Receive(new TimeSpan(0, 0, 5));

                if (message != null)
                {
                    Console.WriteLine("\nReceived message " + ++receivedMessageCount);
                    displayMessageBody(message);
                    displayStandardProperties(message);
                    displayApplicationProperties(message);
                    message.Complete();
                }
                if (Console.KeyAvailable)
                {
                    Console.ReadKey(true);
                    break;
                }
            }
        }


        static MessageReceiver GetMessageReceiver(string destination)
        {
            MessageReceiver receiver = null;

            if (messageReceiverHashtable == null)
            {
                messageReceiverHashtable = new System.Collections.Hashtable();
            }

            if (messageReceiverHashtable.ContainsKey(destination))
            {
                receiver = (MessageReceiver)messageReceiverHashtable[destination];
            }
            else
            {
                Console.WriteLine("Creating message receiver for: " + destination);
                receiver = messagingFactory.CreateMessageReceiver(destination);
                messageReceiverHashtable.Add(destination, receiver);
            }
            return receiver;
        }

        static void displayMessageBody(BrokeredMessage message)
        {
            String messageTypeHint = null;
            
            if (message.Properties.Keys.Contains(Constants.MessageTypePropertyName))
            {
                messageTypeHint = (string) message.Properties[Constants.MessageTypePropertyName];

                switch (messageTypeHint)
                {
                    case "BytesMessage":
                        displayBytesMessageBody(message);
                        break;
                    case "MapMessage":
                        displayMapMessageBody(message);
                        break;
                    case "ObjectMessage":
                        displayObjectMessageBody(message);
                        break;
                    case "StreamMessage":
                        displayStreamMessageBody(message);
                        break;
                    case "TextMessage":
                        displayTextMessageBody(message);
                        break;
                }
            }
        }

        static void displayBytesMessageBody(BrokeredMessage message)
        {
            Console.WriteLine("\tBytesMessage body: ");
            try
            {
                Stream stream = message.GetBody<Stream>();
                int streamLength = (int)stream.Length;
                int numBytesToRead = (streamLength < 10) ? streamLength : 10;

                byte[] byteArray = new byte[numBytesToRead];
                stream.Read(byteArray, 0, numBytesToRead);

                Console.WriteLine("\t\tLength = " + streamLength + ", displaying " + numBytesToRead + " bytes:");
                Console.Write("\t\t");
                for (int i = 0; i < numBytesToRead; i++)
                {
                    Console.Write("[" + (sbyte) byteArray[i] + "]");
                }
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("Caught exception decoding JMSBytesMessage: " + e);
            }
        }

        static void displayMapMessageBody(BrokeredMessage message)
        {
            Console.WriteLine("\tMapMessage body: ");
            try
            {
                Dictionary<String, Object> dictionary = message.GetBody<Dictionary<String, Object>>();

                foreach (String mapItemName in dictionary.Keys)
                {
                    Object mapItemValue = null;
                    if (dictionary.TryGetValue(mapItemName, out mapItemValue))
                    {
                        Console.WriteLine("\t\t"+mapItemName + ": " + mapItemValue + " (" + mapItemValue.GetType() + ")");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Caught exception decoding JMSMapMessage: " + e);
            }
        }

        static void displayObjectMessageBody(BrokeredMessage message)
        {
            Console.WriteLine("\tObjectMessage body: cannot decode serialized Java object.");
        }


        static void displayStreamMessageBody(BrokeredMessage message)
        {
            Console.WriteLine("\tStreamMessage body: ");
            try
            {
                List<Object> list = message.GetBody<List<Object>>();

                foreach (Object item in list)
                {
                    Console.WriteLine("\t\t" + item + " (" + item.GetType() + ")");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Caught exception decoding JMSMapMessage: " + e);
            }
        }

        static void displayTextMessageBody(BrokeredMessage message)
        {
            Console.WriteLine("\tTextMessage body: ");
            try
            {
                Console.WriteLine("\t\tText: " + message.GetBody<String>());
            }
            catch (Exception e)
            {
                Console.WriteLine("Caught exception decoding JMSTextMessage: " + e);
            }
        }


        static void displayStandardProperties(BrokeredMessage message)
        {
            Console.WriteLine("\tStandard properties:");
            Console.WriteLine("\t\tContentType: " + message.ContentType);
            Console.WriteLine("\t\tCorrelationID: " + message.CorrelationId);
            Console.WriteLine("\t\tEnqueuedTimeUtc: " + message.EnqueuedTimeUtc);
            Console.WriteLine("\t\tLabel: " + message.Label);
            Console.WriteLine("\t\tMessageId: " + message.MessageId);
            Console.WriteLine("\t\tReplyTo: " + message.ReplyTo);
            Console.WriteLine("\t\tReplyToSessionId: " + message.ReplyToSessionId);
            Console.WriteLine("\t\tScheduledEnqueueTimeUtc: " + message.ScheduledEnqueueTimeUtc);
            Console.WriteLine("\t\tSessionId: " + message.SessionId);
            Console.WriteLine("\t\tTimeToLive: " + message.TimeToLive);
            Console.WriteLine("\t\tTo: " + message.To);
        }

        static void displayApplicationProperties(BrokeredMessage message)
        {
            if (message.Properties.Keys.Count > 0)
            {
                Console.WriteLine("\tApplication properties:");
                foreach (string name in message.Properties.Keys)
                {
                    Object value = message.Properties[name];
                    Console.WriteLine("\t\t" + name + ": " + value + " (" + value.GetType() + ")" );
                }
                Console.WriteLine();
            }
        }

        static void Shutdown()
        {
            try
            {
                foreach (System.Collections.DictionaryEntry de in messageReceiverHashtable)
                {
                    Console.WriteLine("Closing MessageReceiver for " + de.Key);
                    MessageReceiver mr = (MessageReceiver)de.Value;
                    mr.Close();
                }

                Console.WriteLine("Closing MessagingFactory");
                messagingFactory.Close();

            }
            catch
            {
                Console.WriteLine("An error occurred during shutdown, ignoring.");
            }
        }

    }
}
